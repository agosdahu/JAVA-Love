package tenisz;


public class Main {

	/*
	 * @param args
	 *            the command line arguments
	 * @throws Exception 
	 */
	

	
	public static void main(String[] args){
		Control c = new Control();
		
		/*Player playerS = new Player("Dini", 0, 0, 5);
		Player playerC = new Player("Gabor", 0, 0, 5);
		playerS.setType("Server");
		playerC.setType("Client");
		c.setPlayer1(playerS);
		c.setPlayer2(playerC);*/
		//c.showMenu();	
		//GUI gui = new GUI();
		//gui.showMenu();
		//c.joinSuccesfull(playerC);
		
		
	}
	
	
}
